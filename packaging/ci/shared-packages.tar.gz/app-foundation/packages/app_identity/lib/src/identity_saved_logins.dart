import 'dart:async';
import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

abstract interface class IdentitySavedLogins {
  Future<List<String>> accounts();
  Future<String?> passwordFor(String account);
  Future<void> remember(String account, {String? password});
  Future<void> forget(String account);
}

/// Recent successful logins, isolated by application and canonical service scope.
/// Web persists account names and delegates passwords to the browser.
final class IdentityLoginHistory implements IdentitySavedLogins {
  IdentityLoginHistory({
    required String appId,
    required String Function() serviceScope,
    SharedPreferences? preferences,
    FlutterSecureStorage? secureStorage,
  }) : _appId = appId,
       _serviceScope = serviceScope,
       _preferences = preferences,
       _secureStorage = kIsWeb ? null : secureStorage ?? _defaultSecureStorage;

  static const _limit = 10;
  static const _defaultSecureStorage = FlutterSecureStorage(
    aOptions: AndroidOptions(
      resetOnError: false,
      sharedPreferencesName: 'app_identity_logins_v1',
      keyCipherAlgorithm:
          KeyCipherAlgorithm.RSA_ECB_OAEPwithSHA_256andMGF1Padding,
      storageCipherAlgorithm: StorageCipherAlgorithm.AES_GCM_NoPadding,
    ),
  );

  final String _appId;
  final String Function() _serviceScope;
  final SharedPreferences? _preferences;
  final FlutterSecureStorage? _secureStorage;
  Future<void>? _pending;

  Future<T> _run<T>(Future<T> Function(String key) operation) {
    final scope = sha256.convert(utf8.encode(_serviceScope()));
    final key = 'app_identity.logins.v1.$_appId.$scope';
    var expired = false;
    Future<T> apply() {
      if (expired) throw TimeoutException('Saved login operation expired');
      return operation(key);
    }

    final previous = _pending;
    final result = previous == null ? apply() : previous.then((_) => apply());
    final settled = result.then<void>(
      (_) {},
      onError: (Object _, StackTrace _) {},
    );
    _pending = settled;
    unawaited(
      settled.then((_) {
        if (identical(_pending, settled)) _pending = null;
      }),
    );
    return result.timeout(
      const Duration(seconds: 5),
      onTimeout: () {
        expired = true;
        throw TimeoutException('Saved login storage did not respond');
      },
    );
  }

  Future<Map<String, String?>> _read(String key) async {
    final storage = _secureStorage;
    final raw = storage == null
        ? (await _browserPreferences()).getString(key)
        : await storage.read(key: key);
    if (raw == null) return {};
    final data = jsonDecode(raw) as Map<String, dynamic>;
    return {
      for (final entry in data.entries.take(_limit))
        entry.key: storage == null ? null : entry.value as String?,
    };
  }

  Future<void> _write(String key, Map<String, String?> accounts) async {
    final storage = _secureStorage;
    final value = jsonEncode(accounts);
    if (storage != null) {
      await storage.write(key: key, value: value);
      return;
    }
    final preferences = await _browserPreferences();
    if (!await preferences.setString(key, value)) {
      throw StateError('Saved login storage did not accept the change');
    }
  }

  Future<SharedPreferences> _browserPreferences() async =>
      _preferences ?? await SharedPreferences.getInstance();

  @override
  Future<List<String>> accounts() =>
      _run((key) async => (await _read(key)).keys.toList());

  @override
  Future<String?> passwordFor(String account) => _secureStorage == null
      ? Future.value()
      : _run((key) async => (await _read(key))[account]);

  @override
  Future<void> remember(String account, {String? password}) =>
      _run((key) async {
        final username = account.trim();
        if (username.isEmpty) throw ArgumentError('Account is empty');
        final history = await _read(key);
        history.remove(username);
        await _write(key, {
          username: _secureStorage != null ? password : null,
          ...Map.fromEntries(history.entries.take(_limit - 1)),
        });
      });

  @override
  Future<void> forget(String account) => _run((key) async {
    final history = await _read(key);
    if (!history.containsKey(account)) return;
    history.remove(account);
    await _write(key, history);
  });
}
